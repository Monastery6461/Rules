import os
import yaml

def parcourir_fichiers_yaml(dossier):
    event_ids = []
    print ("test")
    for root, dirs, files in os.walk(dossier):
        for file in files:
            print ("test1")
            if file.endswith(".yaml"):
                print ("test2")
                chemin_fichier = os.path.join(root, file)
                with open(chemin_fichier, 'r') as f:

                    print (chemin_fichier)
                    contenu = yaml.safe_load(f)
                    event_id = contenu.get('EventID')
                    if event_id:
                        event_ids.append(event_id)

    return event_ids

if __name__ == "__main__":
    # Remplacez le chemin par le répertoire que vous souhaitez parcourir
    chemin_dossier = "/home/spike/SIEM/SIMGA-detection-rules/windows-ative_directory/"

    event_ids = parcourir_fichiers_yaml(chemin_dossier)
    print (event_ids)
    if event_ids:
        print("EventIDs trouvés :")
        for event_id in event_ids:
            print(event_id)
    else:
        print("Aucun EventID trouvé dans les fichiers YAML.")
